// agendamentoController.js - Arquivo base
