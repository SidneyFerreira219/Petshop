// agendamento.js - Arquivo base
