// funcionarios.js - Arquivo base
