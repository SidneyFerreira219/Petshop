// pet.js - Arquivo base
