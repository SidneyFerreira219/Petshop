// cliente.js - Arquivo base
