// clienteController.js - Arquivo base
