// agendamentos.js - Arquivo base
