// funcionario.js - Arquivo base
