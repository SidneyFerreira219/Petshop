// pets.js - Arquivo base
