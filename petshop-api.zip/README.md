# Petshop API

## Requisitos
- Node.js
- MySQL

## Instalação
1. Clone o projeto
2. Execute `npm install`
3. Configure o arquivo `.env`
4. Crie o banco de dados `petshopdb` no MySQL
5. Execute `npx sequelize db:migrate`
6. Inicie o servidor com `npm run dev`

## Rotas disponíveis
- /clientes
- /pets
- /servicos
- /agendamentos
- /funcionarios

Todas com suporte a: GET, POST, PUT, DELETE
