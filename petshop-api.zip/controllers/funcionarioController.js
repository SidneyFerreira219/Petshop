// funcionarioController.js - Arquivo base
