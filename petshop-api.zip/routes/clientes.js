// clientes.js - Arquivo base
