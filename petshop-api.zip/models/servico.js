// servico.js - Arquivo base
