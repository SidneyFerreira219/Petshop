// petController.js - Arquivo base
