require('dotenv').config();
const express = require('express');
const app = express();
const clienteRoutes = require('./routes/clientes');
const petRoutes = require('./routes/pets');
const servicoRoutes = require('./routes/servicos');
const agendamentoRoutes = require('./routes/agendamentos');
const funcionarioRoutes = require('./routes/funcionarios');

app.use(express.json());
app.use('/clientes', clienteRoutes);
app.use('/pets', petRoutes);
app.use('/servicos', servicoRoutes);
app.use('/agendamentos', agendamentoRoutes);
app.use('/funcionarios', funcionarioRoutes);

app.listen(process.env.PORT, () => {
  console.log(`Servidor rodando na porta ${process.env.PORT}`);
});
